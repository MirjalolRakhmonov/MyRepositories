﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumericalSystems
{
    class Program
    {
        static void Main(string[] args)
        {
            string input = null;

            MainProgram();

            void MainProgram()
            {
                input = Converter.AskUser();
                try
                {
                    INumericalForm numberSystem;
                    if (input[0] == '0' && input[1] != 'x' && input[1] != 'X' && input[1] != ',')   //for octal
                    {
                        numberSystem = new OctalForm(input);
                    }
                    else if (input[1] == 'x' || input[1] == 'X')  // for hexadecimal
                    {
                        numberSystem = new HexadecimalForm(input);
                    }
                    else // for decimal
                    {
                        numberSystem = new DecimalForm(input);
                    }
                    numberSystem.ShowResults();
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message + " Error try again");
                }
                LoopOfMainProgram();
            }

            void LoopOfMainProgram()
            {
                while (true)
                {
                    Console.WriteLine("Do you want to try another number? \n Type 'yes' or 'exit'");
                    string answer = Console.ReadLine();
                    if (answer == "exit") { Environment.Exit(0); break; }
                    else if (answer == "yes") { Console.Clear(); MainProgram(); break; }
                    else Console.WriteLine("Wrong answer");
                }

            }

            //Converter c1 = new Converter(100);
            ////BinaryForm b1 = new BinaryForm();
            ////c1.NewStrategy(b1);
            ////Console.WriteLine(c1.GetForm());
            //OctalForm o1 = new OctalForm();
            //c1.NewStrategy(o1);
            //Console.WriteLine(c1.GetForm());

            //string hex_value = "10FA";
            //converting hex to integer
            //int int_value = Convert.ToInt32(hex_value, 16);
            //printing the values
            //Console.WriteLine("hex_value = {0}", hex_value);
            //Console.WriteLine("int_value = {0}", int_value);
        }
    }
}
