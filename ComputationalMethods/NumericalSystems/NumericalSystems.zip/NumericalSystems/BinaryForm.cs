﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumericalSystems
{
    /*class BinaryForm : INumericalForm
    {
        string Number;
        double DecimalForm;
        string Binary;
        TableForConvert Table;
        readonly int Base;
        public BinaryForm(string newNumber)
        {
            this.Base = 2;
            this.Table = new TableForConvert();
        }

        public string GetForm(double Number)
        {
            string result = null;
            while ((int)DecimalForm > 0)
            {
                int remainder = (int)DecimalForm % Base;
                result += remainder;
                DecimalForm /= Base;
            }
            return ReverseString(result);
        }

        public double GetDecimal(string Number)
        {
            int Base = 10;
            double DecimalForm = 0;
            char[] array = Number.ToString().ToCharArray();

            for (int i = 0; i < array.Length; i++)
            {
                DecimalForm += double.Parse(array[i].ToString()) * Math.Pow(Base, i);
            }
            return Base;
        }

        private string ReverseString(string Word)
        {
            return string.Join("", Word.Reverse());
        }
    }*/
}
