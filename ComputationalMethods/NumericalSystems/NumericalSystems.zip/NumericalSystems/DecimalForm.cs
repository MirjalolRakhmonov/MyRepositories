﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumericalSystems
{
    class DecimalForm : INumericalForm
    {
        //string Number;
        private double decNumber { get; set; }
        readonly int Base;
        //TableForConvert Table;

        public DecimalForm(string userInput)
        {
            decNumber = double.Parse(userInput);
            Base = 10;
        }

        public void ShowResults()
        {
            Console.WriteLine("In decimal: " + decNumber + "\n" + DecimalToBinary() + "\n" + DecimalToHexa() + "\n" + DecimalToOctal());
        }

        /*public double GetDecimal(string Number)
        {
            int Base = 10;
            double DecimalForm = 0;
            char[] array = Number.ToCharArray();

            for (int i = 0; i < array.Length; i++)
                DecimalForm += double.Parse(array[i].ToString()) * Math.Pow(Base, i);

            return Base;
        }*/

        public string DecToOthers(double DecimalForm)
        {
            string result = null;

            if (DecimalForm < 0)
                throw new System.IndexOutOfRangeException();

            while ((int)DecimalForm > 0)
            {
                int remainder = (int)DecimalForm % Base;
                result += remainder;
                DecimalForm /= Base;
            }
            return ReverseString(result);
        }

        private string ReverseString(string Word)
        {
            return string.Join("", Word.Reverse());
        }

        public string DecimalToBinary()
        {
            return "In binary: " + DecToOthers(2);
        }

        public string DecimalToOctal()
        {
            return "In octal: " + DecToOthers(8);
        }

        public string DecimalToHexa()
        {
            string result = null;

            int Integer = (int)decNumber;
            result += string.Format("{0:X}", Integer); //conversion

            result += string.Format("{0:X}", Integer);

            return "In hexadecimal: " + result;
        }


        private string Reverse(string input)
        {
            char[] temparray = input.ToCharArray();
            int left, right = 0;
            right = temparray.Length - 1;

            for (left = 0; left < right; left++, right--)
            {
                // Swap values of left and right  
                char temp = temparray[left];
                temparray[left] = temparray[right];
                temparray[right] = temp;
            }
            return string.Join("", temparray);
        }
    }
}
