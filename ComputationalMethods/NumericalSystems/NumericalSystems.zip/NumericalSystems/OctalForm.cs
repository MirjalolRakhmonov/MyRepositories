﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumericalSystems
{
    class OctalForm : INumericalForm
    {
        //string Number;
        //double DecimalForm;
        //string Octal;
        readonly int Base;
        //TableForConvert Table;

        private double number { get; set; }

        public OctalForm(string userInput)
        {
            number = double.Parse(userInput);
            Base = 10;
        }

        public string OctalToDecimal()
        {
            int num = (int)number;
            double decValue = 0;

            int baseToPow = 1;

            int temp = num;
            while (temp > 0)
            {
                int lastDigit = temp % 10;
                if (lastDigit > 8) throw new IndexOutOfRangeException();
                temp /= 10;

                // Multiplying last digit with base and saving it
                decValue += lastDigit * baseToPow;

                baseToPow *= 8;
            }
            string result = decValue.ToString();


            //double fractional = number - (double)num;
            double fraction = number - Math.Truncate(number);

            if (fraction != 0) result += (',');

            int Limit = 5;       
            while (true && Limit > 0)
            {
                Limit--;
                fraction *= 8;
                int fractionalBit = (int)fraction;
                if (fraction == 0) break;
                else
                {
                    result += fractionalBit;
                    fraction -= fractionalBit;
                }
            }
            return result;

        }
        public void ShowResults()
            {
                Console.WriteLine("In octal: " + number);
                Console.WriteLine("In decimal: " + OctalToDecimal());
                string Result = OctalToDecimal();
                DecimalForm dec = new DecimalForm(Result);
                Console.WriteLine(dec.DecimalToBinary());
                Console.WriteLine(dec.DecimalToHexa());
            }
            /*public OctalForm()
            {
                this.Base = 8;
                this.Table = new TableForConvert();
            }

            public double GetDecimal(string Number)
            {
                int Base = 10;
                double DecimalForm = 0;
                char[] array = Number.ToCharArray();

                for (int i = 0; i < array.Length; i++)
                    DecimalForm += double.Parse(array[i].ToString()) * Math.Pow(Base, i);

                return Base;
            }

            public string GetForm(double DecimalForm)
            {
                string result = null;
                while ((int)DecimalForm > 0)
                {
                    int remainder = (int)DecimalForm % Base;
                    result += remainder;
                    DecimalForm /= Base;
                }


                return ReverseString(result);
            }

            private string ReverseString(string Word)
            {
                return string.Join("", Word.Reverse());
            } */
        }
    }
