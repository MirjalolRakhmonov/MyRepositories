﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NumericalSystems
{
    class HexadecimalForm : INumericalForm
    {
        //string Number;
        //double DecimalForm;
        //string HexaDecimal;
        readonly int Base;
        //TableForConvert Table;
        public string UserInput { get; set; }

        public HexadecimalForm(string newUserInput)
        {
            this.UserInput = newUserInput;
            Base = 16;
        }

        public double HexToDec()
        {
            double result = 0;
            //string FractionalPart = null;
            string IntegralPart;

            if (UserInput.Contains(','))
            {
                string[] SplittedNumber = UserInput.Split(',');

                IntegralPart = SplittedNumber[0];
                //FractionalPart = SplittedNumber[1];
            }
            else IntegralPart = UserInput;

            int count = IntegralPart.Length - 1;
            for (int i = 0; i < IntegralPart.Length; i++)
            {
                int temp = 0;
                switch (IntegralPart[i])
                {
                    case 'x': break;
                    case 'A': temp = 10; break;
                    case 'B': temp = 11; break;
                    case 'C': temp = 12; break;
                    case 'D': temp = 13; break;
                    case 'E': temp = 14; break;
                    case 'F': temp = 15; break;
                }
                result += temp * (int)(Math.Pow(16, count));
                count--;
            }
            return result;
        }
        public void ShowResults()
        {
            Console.WriteLine("In hexadecimal: " + UserInput);
            Console.WriteLine("In decimal: " + HexToDec());
            double result = HexToDec();
            DecimalForm decimalSystems = new DecimalForm(result.ToString());
            Console.WriteLine(decimalSystems.DecimalToBinary());
            Console.WriteLine(decimalSystems.DecimalToOctal());
        }
        /*public double GetDecimal(string Number)
        {
            int Base = 10;
            double DecimalForm = 0;
            char[] array = Number.ToCharArray();

            for (int i = 0; i < array.Length; i++)
                DecimalForm += double.Parse(array[i].ToString()) * Math.Pow(Base, i);

            return Base;
        }

        public string GetForm(double DecimalForm)
        {
            string result = null;
            while ((int)DecimalForm > 0)
            {
                int remainder = (int)DecimalForm % Base;
                result += remainder;
                DecimalForm /= Base;
            }
            return ReverseString(result);
        }

        private string ReverseString(string Word)
        {
            return string.Join("", Word.Reverse());
        }*/

    }
}
